<?php
/** Old English (Ænglisc)
 *
 * @file
 * @ingroup Languages
 */

$namespaceNames = [
	NS_SPECIAL          => 'Syndrig',
	NS_TALK             => 'Mōtung',
	NS_USER             => 'Brūcend',
	NS_USER_TALK        => 'Brūcendmōtung',
	NS_FILE             => 'Ymele',
	NS_FILE_TALK        => 'Ymelmōtung',
	NS_MEDIAWIKI_TALK   => 'MediaWikimōtung',
	NS_TEMPLATE         => 'Bysen',
	NS_TEMPLATE_TALK    => 'Bysenmōtung',
	NS_HELP             => 'Help',
	NS_HELP_TALK        => 'Helpmōtung',
	NS_CATEGORY         => 'Flocc',
	NS_CATEGORY_TALK    => 'Floccmōtung',
];

$namespaceAliases = [
	'Gesprec'       => NS_TALK,
	'Motung'        => NS_TALK,
	'Brucend'       => NS_USER,
	'Brucendmotung' => NS_USER_TALK,
	'Biliþ'         => NS_FILE,
	'Biliþmotung'   => NS_FILE_TALK,
	'Biliþmōtung'   => NS_FILE_TALK,
	'Bysengesprec'  => NS_TEMPLATE_TALK,
	'Bysenmotung'   => NS_TEMPLATE_TALK,
	'Helpgesprec'   => NS_HELP_TALK,
	'Helpmotung'    => NS_HELP_TALK,
	'Floccgesprec'  => NS_CATEGORY_TALK,
	'Floccmotung'   => NS_CATEGORY_TALK,
];
