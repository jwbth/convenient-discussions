<?php
/** Sassaresu (Sassaresu)
 *
 * @file
 * @ingroup Languages
 *
 * @author Antofa
 * @author Cornelia
 * @author Felis
 * @author Jun Misugi
 * @author Kaganer
 */

$fallback = 'it';

$namespaceNames = [
	NS_SPECIAL          => 'Ippiziari',
	NS_TALK             => 'Dischussioni',
	NS_USER             => 'Utenti',
	NS_USER_TALK        => 'Dischussioni_utenti',
	NS_PROJECT_TALK     => 'Dischussioni_$1',
	NS_FILE             => 'Immagina',
	NS_FILE_TALK        => 'Dischussioni_immagina',
	NS_MEDIAWIKI_TALK   => 'Dischussioni_MediaWiki',
	NS_TEMPLATE         => 'Mudellu',
	NS_TEMPLATE_TALK    => 'Dischussioni_mudellu',
	NS_HELP             => 'Aggiuddu',
	NS_HELP_TALK        => 'Dischussioni_aggiuddu',
	NS_CATEGORY         => 'Categuria',
	NS_CATEGORY_TALK    => 'Dischussioni_categuria',
];

/** @phpcs-require-sorted-array */
$specialPageAliases = [
	'Allmessages'               => [ 'Imbasciaddi' ],
	'Allpages'                  => [ 'TuttiLiPàgini' ],
	'Ancientpages'              => [ 'PàginiMancuRizzenti' ],
	'Block'                     => [ 'Brocca' ],
	'BlockList'                 => [ 'IPBroccaddi' ],
	'Booksources'               => [ 'ZirchaISBN' ],
	'BrokenRedirects'           => [ 'RinviiIbbagliaddi' ],
	'Categories'                => [ 'Categuri' ],
	'ChangePassword'            => [ 'RimpusthàParàuraDÓrdhini' ],
	'Contributions'             => [ 'Cuntributi', 'CuntributiUtente' ],
	'Deadendpages'              => [ 'PàginiChenaIscidda' ],
	'DoubleRedirects'           => [ 'RinviiDoppi' ],
	'Emailuser'                 => [ 'InviaPosthaErettrònica' ],
	'Export'                    => [ 'Ippurtha' ],
	'Fewestrevisions'           => [ 'PàginiCunMancuRibisioni' ],
	'Import'                    => [ 'Impurtha' ],
	'Listadmins'                => [ 'Amministhradori' ],
	'Listfiles'                 => [ 'Immagini' ],
	'Listredirects'             => [ 'Rinvii' ],
	'Listusers'                 => [ 'Utenti', 'ErencuUtenti' ],
	'Lockdb'                    => [ 'BroccaDB' ],
	'Log'                       => [ 'Rigisthru', 'Rigisthri', 'Registro', 'Registri' ],
	'Lonelypages'               => [ 'PàginaÒiffana' ],
	'Longpages'                 => [ 'PàginiPiùLonghi' ],
	'MIMEsearch'                => [ 'ZirchaMIME' ],
	'Mostcategories'            => [ 'PàginiCunPiùCateguri' ],
	'Mostimages'                => [ 'ImmaginiPiùRiciamaddi' ],
	'Mostlinked'                => [ 'PàginiPiùRiciamaddi' ],
	'Mostlinkedcategories'      => [ 'CateguriPiùRiciamaddi' ],
	'Mostlinkedtemplates'       => [ 'MudelliPiùRiciamaddi' ],
	'Mostrevisions'             => [ 'PàginiCunPiùRibisioni' ],
	'Movepage'                  => [ 'Ippustha', 'Rinumina' ],
	'Mycontributions'           => [ 'MéCuntributi' ],
	'Mypage'                    => [ 'MeaPàginaUtenti' ],
	'Mytalk'                    => [ 'MéDischussioni' ],
	'Newimages'                 => [ 'ImmaginiRizzenti' ],
	'Newpages'                  => [ 'PàginiPiùRizzenti' ],
	'Preferences'               => [ 'Prifirènzi' ],
	'Prefixindex'               => [ 'Prefissi' ],
	'Protectedpages'            => [ 'PàginiPrutiggiddi' ],
	'Randompage'                => [ 'PàginaCasuari' ],
	'Randomredirect'            => [ 'RinviuCasuari' ],
	'Recentchanges'             => [ 'UlthimiMudìfigghi' ],
	'Recentchangeslinked'       => [ 'MudìfigghiLiaddi' ],
	'Revisiondelete'            => [ 'CanzillaRibisioni' ],
	'Search'                    => [ 'Zircha', 'Ricerca' ],
	'Shortpages'                => [ 'PàginiPiùCorthi' ],
	'Specialpages'              => [ 'PàginiIppiziari' ],
	'Statistics'                => [ 'Sthatisthigghi' ],
	'Uncategorizedcategories'   => [ 'CateguriNòCategurizzaddi' ],
	'Uncategorizedimages'       => [ 'ImmaginiChenaCateguri' ],
	'Uncategorizedpages'        => [ 'PàginiChenaCateguri' ],
	'Uncategorizedtemplates'    => [ 'MudelliChenaCateguri' ],
	'Undelete'                  => [ 'TurraChePrimma' ],
	'Unlockdb'                  => [ 'IbbruccaDB' ],
	'Unusedcategories'          => [ 'CateguriInutirizaddi' ],
	'Unusedimages'              => [ 'FileInutirizaddi' ],
	'Unusedtemplates'           => [ 'MudelliInutirizaddi' ],
	'Unwatchedpages'            => [ 'PàginiNòAbbaidaddi' ],
	'Upload'                    => [ 'Carrigga' ],
	'Userlogin'                 => [ 'Intra', 'Accesso' ],
	'Userlogout'                => [ 'Isci', 'Uscita' ],
	'Userrights'                => [ 'PrimmissiUtenti' ],
	'Version'                   => [ 'Versioni' ],
	'Wantedcategories'          => [ 'CateguriDumandaddi' ],
	'Wantedpages'               => [ 'PàginiPiùDumandaddi' ],
	'Watchlist'                 => [ 'AbbaidaddiIppiziari' ],
	'Whatlinkshere'             => [ 'PuntaniInogghi' ],
	'Withoutinterwiki'          => [ 'PàginiChenaInterwiki' ],
];
