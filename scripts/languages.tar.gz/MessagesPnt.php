<?php
/** Pontic (Ποντιακά)
 *
 * @file
 * @ingroup Languages
 *
 * @author Consta
 * @author Crazymadlover
 * @author Kaganer
 * @author Omnipaedista
 * @author Reedy
 * @author Sinopeus
 * @author Urhixidur
 * @author ZaDiak
 */

$fallback = 'el';

$namespaceNames = [
	NS_MEDIA            => 'Μέσον',
	NS_SPECIAL          => 'Ειδικόν',
	NS_TALK             => 'Καλάτσεμαν',
	NS_USER             => 'Χρήστες',
	NS_USER_TALK        => 'Καλάτσεμαν_χρήστε',
	NS_PROJECT_TALK     => '$1_καλάτσεμαν',
	NS_FILE             => 'Αρχείον',
	NS_FILE_TALK        => 'Καλάτσεμαν_αρχείονος',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_talk',
	NS_TEMPLATE         => 'Πρότυπον',
	NS_TEMPLATE_TALK    => 'Καλάτσεμαν_πρότυπι',
	NS_HELP             => 'Βοήθειαν',
	NS_HELP_TALK        => 'Καλάτσεμαν_βοήθειας',
	NS_CATEGORY         => 'Κατηγορίαν',
	NS_CATEGORY_TALK    => 'Καλάτσεμαν_κατηγορίας',
];

$namespaceAliases = [
	'Εικόναν' => NS_FILE,
	'Καλάτσεμαν_εικόνας' => NS_FILE_TALK,
];

$datePreferences = [
	'default',
	'pnt',
	'ISO 8601',
];

$defaultDateFormat = 'pnt';

$dateFormats = [
	'pnt time' => 'H:i',
	'pnt date' => 'j xg Y',
	'pnt both' => 'H:i, j xg Y',
];
