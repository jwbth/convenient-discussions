<?php
/** Atikamekw
 *
 * @file
 * @ingroup Languages
 */

$fallback = 'fr';

$namespaceNames = [
	NS_MEDIA            => 'Tipatcimoctakewin',
	NS_SPECIAL          => 'Kotakahi',
	NS_TALK             => 'Ke_ici_aimihitonaniwok',
	NS_USER             => 'Ka_notcitatc',
	NS_USER_TALK        => 'Ke_ici_aimihitonaniwok_notcita_iriniw',
	NS_PROJECT_TALK     => 'Ke_ici_aimihitonaniwok_$1',
	NS_FILE             => 'Natisinahikaniwoc',
	NS_FILE_TALK        => 'Ke_ici_aimihitonaniwok_natisinihikaniwoc',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Ke_ici_aimihitonaniwok_MediaWiki',
	NS_TEMPLATE         => 'Tipapitcikesinihikan',
	NS_TEMPLATE_TALK    => 'Ke_ici_arimotcikatek_tipapitcikesinihikan',
	NS_HELP             => 'Witcihikoiin',
	NS_HELP_TALK        => 'Ke_ici_aimihitonaniwok_witcihewinik',
	NS_CATEGORY         => 'Tipanictawin',
	NS_CATEGORY_TALK    => 'Ke_ici_aimihitonaniwok_tipanictawin',
];

$namespaceAliases = [
	'Tapapitcikesinihikan' => NS_TEMPLATE,
	'Ke_ici_arimotcikatek_tapapitcikesinihikan' => NS_TEMPLATE_TALK,
];
