<?php
/** Ido (Ido)
 *
 * @file
 * @ingroup Languages
 */

$fallback = 'eo';

$namespaceNames = [
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Specala',
	NS_TALK             => 'Debato',
	NS_USER             => 'Uzanto',
	NS_USER_TALK        => 'Uzanto_Debato',
	NS_PROJECT_TALK     => '$1_Debato',
	NS_FILE             => 'Arkivo',
	NS_FILE_TALK        => 'Arkivo_Debato',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_Debato',
	NS_TEMPLATE         => 'Shablono',
	NS_TEMPLATE_TALK    => 'Shablono_Debato',
	NS_HELP             => 'Helpo',
	NS_HELP_TALK        => 'Helpo_Debato',
	NS_CATEGORY         => 'Kategorio',
	NS_CATEGORY_TALK    => 'Kategorio_Debato',
];

$namespaceGenderAliases = [
	NS_USER => [ 'male' => 'Uzanto', 'female' => 'Uzantino' ],
	NS_USER_TALK => [ 'male' => 'Uzanto_Debato', 'female' => 'Uzantino_Debato' ],
];

$namespaceAliases = [
	'Imajo' => NS_FILE,
	'Imajo_Debato' => NS_FILE_TALK,
	'Modelo' => NS_TEMPLATE,
	'Modelo_Debato' => NS_TEMPLATE_TALK,
];

/** @phpcs-require-sorted-array */
$specialPageAliases = [
	'Allmessages'               => [ 'OmnaMesaji' ],
	'Allpages'                  => [ 'OmnaPagini' ],
	'Ancientpages'              => [ 'AncienaPagini' ],
	'Blankpage'                 => [ 'BlankaPagini' ],
	'Block'                     => [ 'Blokusar', 'BlokusarIP', 'BlokusarUzanto' ],
	'BlockList'                 => [ 'BlokusoListo' ],
	'Booksources'               => [ 'LibroFonti' ],
	'Categories'                => [ 'Kategorii' ],
	'ChangePassword'            => [ 'ChanjarPasovorto', 'Ripasvortizar' ],
	'Confirmemail'              => [ 'KontrolarEposto' ],
	'Contributions'             => [ 'Kontributaji' ],
	'CreateAccount'             => [ 'KrearKonto' ],
	'DeletedContributions'      => [ 'EfacitaKontributaji' ],
	'Emailuser'                 => [ 'EpostarUzanto' ],
	'Export'                    => [ 'Ekportar' ],
	'Listadmins'                => [ 'AdministrantiListo' ],
	'Listbots'                  => [ 'RobotoListo' ],
	'Listfiles'                 => [ 'ArkivoListo' ],
	'Listgrouprights'           => [ 'GrupoYuroListo' ],
	'Listredirects'             => [ 'RidirektiloListo' ],
	'Listusers'                 => [ 'UzantoListo' ],
	'Log'                       => [ 'Registrari', 'Registraro' ],
	'Longpages'                 => [ 'LongaPagini' ],
	'Movepage'                  => [ 'MovarPagino' ],
	'Mycontributions'           => [ 'MeaKontributaji' ],
	'Mypage'                    => [ 'MeaPagino' ],
	'Mytalk'                    => [ 'MeaDiskuti' ],
	'Newimages'                 => [ 'NovaArkivi' ],
	'Newpages'                  => [ 'NovaPagini' ],
	'Preferences'               => [ 'Preferaji' ],
	'Prefixindex'               => [ 'PrefixoIndexo' ],
	'Protectedpages'            => [ 'ProtektitaPagini' ],
	'Protectedtitles'           => [ 'ProtektitaTituli' ],
	'Randompage'                => [ 'HazardaPagino' ],
	'Randomredirect'            => [ 'HazardaRidirektilo' ],
	'Recentchanges'             => [ 'RecentaChanji' ],
	'Recentchangeslinked'       => [ 'RelatantaChanji', 'RecentaChanjiLigata' ],
	'Revisiondelete'            => [ 'VersionoEfacar', 'EfacarVersiono' ],
	'Search'                    => [ 'Serchar' ],
	'Shortpages'                => [ 'KurtaPagini' ],
	'Specialpages'              => [ 'SpecalaPagini' ],
	'Statistics'                => [ 'Statistiko' ],
	'Uncategorizedcategories'   => [ 'NekategoriizitaKategorii' ],
	'Uncategorizedimages'       => [ 'NekategoriizitaArkivi' ],
	'Uncategorizedpages'        => [ 'NekategoriizitaPagini' ],
	'Uncategorizedtemplates'    => [ 'NekategoriizitaShabloni' ],
	'Unusedcategories'          => [ 'NeuzataKategorii' ],
	'Unusedimages'              => [ 'NeuzataArkivi' ],
	'Unusedtemplates'           => [ 'NeuzataShabloni' ],
	'Unwatchedpages'            => [ 'NesurveyataPagini' ],
	'Upload'                    => [ 'AdkargarArkivo' ],
	'Userlogin'                 => [ 'Enirar' ],
	'Userlogout'                => [ 'Ekirar' ],
	'Version'                   => [ 'Versiono' ],
	'Wantedcategories'          => [ 'BezonataKategorii' ],
	'Wantedfiles'               => [ 'BezonataArkivi' ],
	'Wantedpages'               => [ 'BezonataPagini' ],
	'Wantedtemplates'           => [ 'BezonataShabloni' ],
	'Watchlist'                 => [ 'Surveyaji' ],
	'Whatlinkshere'             => [ 'QuoLigasHike' ],
];
