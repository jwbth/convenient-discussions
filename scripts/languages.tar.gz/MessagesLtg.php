<?php
/** Latgalian (latgaļu)
 *
 * @file
 * @ingroup Languages
 *
 * @author Dark Eagle
 * @author Gleb Borisov
 * @author Jureits
 * @author Reedy
 */

$fallback = 'lv';

$namespaceNames = [
	NS_MEDIA            => 'Medeja',
	NS_SPECIAL          => 'Seviškuo',
	NS_TALK             => 'Sprīža',
	NS_USER             => 'Lītuotuojs',
	NS_USER_TALK        => 'Sprīža_ap_lītuotuoju',
	NS_PROJECT_TALK     => 'Sprīža_ap_{{GRAMMAR:accusative|$1}}',
	NS_FILE             => 'Fails',
	NS_FILE_TALK        => 'Sprīža_ap_failu',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Sprīža_ap_MediaWiki',
	NS_TEMPLATE         => 'Taiss',
	NS_TEMPLATE_TALK    => 'Sprīža_ap_taisu',
	NS_HELP             => 'Paleigs',
	NS_HELP_TALK        => 'Sprīža_ap_paleigu',
	NS_CATEGORY         => 'Kategoreja',
	NS_CATEGORY_TALK    => 'Sprīža_ap_kategoreju',
];
