<?php
/** Inari Sámi (anarâškielâ)
 *
 * @file
 * @ingroup Languages
 *
 * @author Muotâ
 */

$fallback = 'fi';

$namespaceNames = [
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Tooimah',
	NS_TALK             => 'Savâstâllâm',
	NS_USER             => 'Kevttee',
	NS_USER_TALK        => 'Savâstâllâm_kevttest',
	NS_PROJECT_TALK     => 'Savâstâllâm_$1',
	NS_FILE             => 'Tiätuvuárkká',
	NS_FILE_TALK        => 'Savâstâllâm_tiätuvuárhást',
	NS_MEDIAWIKI        => 'Systeemviestâ',
	NS_MEDIAWIKI_TALK   => 'Savâstâllâm_systeemviestâst',
	NS_TEMPLATE         => 'Myenster',
	NS_TEMPLATE_TALK    => 'Savâstâllâm_myensterist',
	NS_HELP             => 'Raavâ',
	NS_HELP_TALK        => 'Savâstâllâm_ravvust',
	NS_CATEGORY         => 'Luokka',
	NS_CATEGORY_TALK    => 'Savâstâllâm_luokkaast',
];

$defaultDateFormat = 'dmy';

$dateFormats = [
	'dmy time' => 'H.i',
	'dmy date' => 'j. M Y',
	'dmy both' => 'j. M Y "tme" H.i',
];

$linkTrail = '/^([a-zâčđŋšžäá]+)(.*)$/sDu';
