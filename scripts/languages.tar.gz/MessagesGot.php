<?php
/** Gothic (Gothic)
 *
 * @file
 * @ingroup Languages
 */

$namespaceNames = [
	NS_USER             => '𐌽𐌹𐌿𐍄𐌰𐌽𐌳𐍃',
	NS_USER_TALK        => '𐌽𐌹𐌿𐍄𐌰𐌽𐌳𐌹𐍃_𐌲𐌰𐍅𐌰𐌿𐍂𐌳𐌾𐌰',
	NS_PROJECT_TALK     => '𐌸𐌹𐍃_$1_𐌲𐌰𐍅𐌰𐌿𐍂𐌳𐌾𐌰',
	NS_FILE             => '𐍆𐌴𐌹𐌻𐌰',
	NS_FILE_TALK        => '𐍆𐌴𐌹𐌻𐌹𐌽𐍃_𐌲𐌰𐍅𐌰𐌿𐍂𐌳𐌾𐌰',
	NS_TEMPLATE         => '𐍆𐌰𐌿𐍂𐌰𐌼𐌴𐌻𐌴𐌹𐌽𐍃',
	NS_TEMPLATE_TALK    => '𐍆𐌰𐌿𐍂𐌰𐌼𐌴𐌻𐌴𐌹𐌽𐌰𐌹𐍃_𐌲𐌰𐍅𐌰𐌿𐍂𐌳𐌾𐌰',
	NS_HELP             => '𐌷𐌹𐌻𐍀𐌰',
	NS_HELP_TALK        => '𐌷𐌹𐌻𐍀𐍉𐍃_𐌲𐌰𐍅𐌰𐌿𐍂𐌳𐌾𐌰',
	NS_CATEGORY         => '𐌷𐌰𐌽𐍃𐌰',
	NS_CATEGORY_TALK    => '𐌷𐌰𐌽𐍃𐍉𐍃_𐌲𐌰𐍅𐌰𐌿𐍂𐌳𐌾𐌰',
];

/** @phpcs-require-sorted-array */
$specialPageAliases = [
	'Allpages'                  => [ '𐌰𐌻𐌻𐍃𐍃𐌴𐌹𐌳𐍉𐌽𐍃' ],
	'Recentchanges'             => [ '𐌰𐍆𐍄𐌿𐌼𐌹𐍃𐍄𐍉𐍃𐌼𐌰𐌹𐌳𐌴𐌹𐌽𐌴𐌹𐍃' ],
];
